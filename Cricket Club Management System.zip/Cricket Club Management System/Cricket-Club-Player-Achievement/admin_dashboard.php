<?php
session_start();

// Redirect to login if user is not logged in or not an admin
if (!isset($_SESSION['username']) || $_SESSION['usertype'] != 'admin') {
    header('Location: login.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Player Information List - Admin Dashboard</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            font-family: 'Times New Roman', Times, serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: darkblue;
            padding: 10px 20px;
        }

        .navbar h1 {
            color: white;
            margin: 0;
        }

        .navbar a {
            text-decoration: none;
            padding: 10px 20px;
            color: white;
            font-size: 16px;
        }

        .navbar a:hover,
        .dropbtn:hover {
            background-color: blue;
        }

        .table-container {
            padding: 30px;
            text-align: center;
        }

        h2 {
            color: darkblue;
        }

        table {
            background-color: white;
            margin: 0 auto;
            border-collapse: collapse;
            width: 100%;
            max-width: 1200px;
        }

        th, td {
            padding: 10px;
            border: 1px solid black;
        }

        th {
            background-color: darkblue;
            color: white;
        }

        .update, .delete {
            color: white;
            border: none;
            height: 25px;
            width: 70px;
            font-weight: bold;
            cursor: pointer;
            border-radius: 4px;
        }

        .update {
            background-color: green;
        }

        .delete {
            background-color: red;
        }

        /* Dropdown styling */
        .dropdown {
            position: relative;
            display: inline-block;
        }

        .dropbtn {
            font-size: 16px;
            border: none;
            outline: none;
            color: white;
            background-color: inherit;
            padding: 14px 16px;
            cursor: pointer;
            font-family: inherit;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: darkblue;
            min-width: 160px;
            z-index: 1;
        }

        .dropdown-content a {
            color: white;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            text-align: left;
        }

        .dropdown-content a:hover {
            background-color: rgb(130,106,251);
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        .logout {
            margin-left: 20px;
        }
    </style>
</head>
<body>

<div class="navbar">
    <h1>Admin Panel</h1>
    <div>
        <div class="dropdown">
            <button class="dropbtn">Registration</button>
            <div class="dropdown-content">
                <a href="Insert.php">Player</a>
                <a href="#">Coach</a>
                <a href="#">Medical Staff</a>
            </div>
        </div>
        <div class="dropdown">
            <button class="dropbtn">Contracts</button>
            <div class="dropdown-content">
                <a href="player_contracts.php">Player</a>
                <a href="#">Coach</a>
                <a href="#">Medical Staff</a>
            </div>
        </div>
        <div class="dropdown">
            <button class="dropbtn">Matches</button>
            <div class="dropdown-content">
                <a href="matches_admin.php">Fixtures & Results</a>
                <a href="matches_insert.php">Insert Match Details</a>
            </div>
        </div>
        <div class="dropdown">
            <button class="dropbtn">Match Scorer</button>
            <div class="dropdown-content">
                <a href="match_best_scorer.php">Scorers</a>
                <a href="match_scorer_insert.php">Insert Scorer</a>
            </div>
        </div>
        <div class="dropdown">
            <button class="dropbtn">Achievements</button>
            <div class="dropdown-content">
                <a href="achievement.php">Awards</a>
                <a href="award_insert.php">Insert Award Details</a>
            </div>
        </div>
        <a class="logout" href="logout.php">Logout</a>
    </div>
</div>

<div class="table-container">
    <?php
    include("database.php");

    $query = "SELECT * FROM Player 
              NATURAL JOIN Player_Education 
              NATURAL JOIN Player_Training 
              NATURAL JOIN Registration";
    $result = mysqli_query($conn, $query);
    $total = mysqli_num_rows($result);

    if ($total > 0) {
        echo "<h2>PLAYER Information List</h2><br>";
        echo "<table>
                <tr>
                    <th>First Name</th>
                    <th>Email</th>
                    <th>Phone Number</th>
                    <th>Nationality</th>
                    <th>Date of Birth</th>
                    <th>Age</th>
                    <th>Degree</th>
                    <th>Institute</th>
                    <th>Passing Year</th>
                    <th>Academy</th>
                    <th>Specialization</th>
                    <th>Operations</th>
                </tr>";
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>
                    <td>{$row['first_name']}</td>
                    <td>{$row['email']}</td>
                    <td>{$row['phone_number']}</td>
                    <td>{$row['nationality']}</td>
                    <td>{$row['dob']}</td>
                    <td>{$row['age']}</td>
                    <td>{$row['degree']}</td>
                    <td>{$row['institution']}</td>
                    <td>{$row['passing_year']}</td>
                    <td>{$row['academy']}</td>
                    <td>{$row['specialization']}</td>
                    <td>
                        <a href='update.php?player_id={$row['player_id']}'><button class='update'>Update</button></a>
                        <a href='delete.php?player_id={$row['player_id']}' onclick='return confirmDelete();'><button class='delete'>Delete</button></a>
                    </td>
                </tr>";
        }
        echo "</table>";
    } else {
        echo "<p>No player records found.</p>";
    }
    ?>
</div>

<script>
    function confirmDelete() {
        return confirm('Are you sure you want to delete this record?');
    }
</script>

</body>
</html>
