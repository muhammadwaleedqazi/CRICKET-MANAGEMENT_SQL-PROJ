<?php
session_start();
include("database.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./login-style.css">
    <title>ADMIN LOGIN PANEL</title>
</head>
<body>
    <div class="center">
        <h1>LOGIN</h1>
        <form action="#" method="POST">
            <div class="form">
                <input type="text" name="username" class="textfield" placeholder="Username" required>
                <input type="password" name="password" class="textfield" placeholder="Password" required>
                <div class="forgetpass"><a href="#" class="link" onclick="message()">Forget Password?</a></div>
                <input type="submit" name="login" value="Login" class="btn">
            </div>
        </form>
    </div>
    <script>
        function message(){
            alert("Please contact the system administrator");
        }
    </script>
</body>
</html>

<?php
if (isset($_POST['login'])) {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    $hashedPassword = hash('sha256', $password);

    // Check in Player_Login table
    $queryPlayer = "SELECT * FROM Player_Login WHERE username = '$username'";
    $resultPlayer = mysqli_query($conn, $queryPlayer);

    if ($resultPlayer && mysqli_num_rows($resultPlayer) > 0) {
        $row = mysqli_fetch_assoc($resultPlayer);
        if ($row['usertype'] === 'player' && $hashedPassword === $row['password']) {
            $_SESSION['username'] = $username;
            $_SESSION['usertype'] = 'player';
            header('Location: player_profile.php');
            exit;
        }
    }

    // Check in Admin Login table
    $queryAdmin = "SELECT * FROM Login WHERE username = '$username'";
    $resultAdmin = mysqli_query($conn, $queryAdmin);

    if ($resultAdmin && mysqli_num_rows($resultAdmin) > 0) {
        $row2 = mysqli_fetch_assoc($resultAdmin);
        if ($row2['usertype'] === 'admin' && $hashedPassword === $row2['password']) {
            $_SESSION['username'] = $username;
            $_SESSION['usertype'] = 'admin';
            header('Location: admin_dashboard.php');
            exit;
        }
    }

    // If both checks failed:
    echo "<script>alert('Login Failed! Incorrect username or password.');</script>";
}
?>
