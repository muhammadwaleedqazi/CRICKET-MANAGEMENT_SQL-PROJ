# Cricket Club Management System

## 👥 Group Members
- Muhammad Mubashir Ali - 241845
- Second Member Name - 241896

## 📌 Project Description
This is a web-based system for managing cricket players, their achievements, and match statistics using PHP and MySQL.

## 🛠️ Setup Instructions

### 1. Restore the Database
- Open [phpMyAdmin](http://localhost/phpmyadmin)
- Create a database named `cricket_club`
- Click **Import** and select `clubdatabase.sql` from this project folder

### 2. Run the Project
- Put this folder in `C:\xampp\htdocs\`
- Start Apache and MySQL from XAMPP
- Visit [http://localhost/Cricket%20Club%20Management%20System/Cricket-Club-Player-Achievement](http://localhost/Cricket%20Club%20Management%20System/Cricket-Club-Player-Achievement)

## 💡 Sample Queries
```sql
SELECT * FROM players WHERE runs > 500;


6. **Save** the file and close Notepad.

---

## ✅ **Option 2: Using VS Code (If you're comfortable)**

1. Open your folder in **VS Code**
2. Click **File > New File**
3. Name it `README.md`
4. Paste the same content from above
5. Press `Ctrl + S` to save

---

## ✅ Next Step: Add it to Git

Now open Git Bash (or Command Prompt) inside your project folder and run:

```bash
git add README.md
git commit -m "Added README with project setup and details"
git push

